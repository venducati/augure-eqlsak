'use client';

import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, ChevronRight, Eye, Layers3, MapPin, Minus, Plus, Route, ShieldCheck } from 'lucide-react';
import { DUNGEONS } from './Dungeon3D';

type Segment = { x1: number; y1: number; z1: number; x2: number; y2: number; z2: number };

const dungeonNotes: Record<string, { adjacent: string; character: string; danger: string; travel: string }> = {
  blackburrow: { adjacent: 'Qeynos Hills · Everfrost Peaks', character: 'Gnoll stronghold with upper ledges, a central pit, and descending tunnels.', danger: 'Fleeing gnolls can assemble dangerous trains. Confirm the drop before descending.', travel: 'Enter from northeastern Qeynos Hills or through the Everfrost canyon passage.' },
  mistmoore: { adjacent: 'Lesser Faydark', character: 'Castle grounds, graveyard, ramp, courtyard and interior castle camps.', danger: 'Aggressive social creatures and narrow pulls make trains especially dangerous.', travel: 'Reach the castle entrance from Lesser Faydark; confirm local faction and escape route.' },
  paw: { adjacent: 'South Karana', character: 'Splitpaw gnoll tunnels with multiple wings and deeper named camps.', danger: 'Long corridors and social gnolls make retreat paths important.', travel: 'The entrance is in South Karana; establish the exit route before moving deep.' },
  befallen: { adjacent: 'West Commonlands', character: 'A compact, multi-level undead ruin with locked progression.', danger: 'Drops between floors, locked doors, and narrow passages can cut off retreat.', travel: 'Enter from West Commonlands and verify required keys before descending.' },
  najena: { adjacent: 'Lavastorm Mountains', character: 'A key-driven dungeon of cells, undead rooms, guards and magician encounters.', danger: 'Pit traps and locked progression can strand an unprepared group.', travel: 'The entrance lies in southeastern Lavastorm Mountains.' },
  gukbottom: { adjacent: 'Upper Guk', character: 'A sprawling lower complex of froglok camps, undead wings and water routes.', danger: 'Complex junctions and aggressive camps make route discipline essential.', travel: 'Descend from Upper Guk; confirm the intended wing and evacuation plan first.' },
};

function sourceClass(source: string) {
  return /User-Verified/i.test(source) ? 'verified' : /EQL/i.test(source) ? 'eql' : 'legacy';
}

export default function DungeonGuide({ initialDungeon }: { initialDungeon?: string }) {
  const [zone, setZone] = useState(() => Math.max(0, DUNGEONS.findIndex((d) => d.name === initialDungeon || d.id === initialDungeon)));
  const [segments, setSegments] = useState<Segment[]>([]);
  const [active, setActive] = useState<(typeof DUNGEONS)[number]['spawns'][number] | null>(null);
  const [floor, setFloor] = useState('all');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [zoom, setZoom] = useState(1);
  const dungeon = DUNGEONS[zone];
  const notes = dungeonNotes[dungeon.id];

  useEffect(() => {
    setActive(null); setFloor('all'); setZoom(1);
    void fetch(`/maps/${dungeon.id}.txt`).then((r) => r.text()).then((text) => {
      const parsed = text.split(/\r?\n/).flatMap((line) => {
        if (!line.startsWith('L ')) return [];
        const n = line.slice(2).split(',').map(Number);
        return n.length >= 6 && n.slice(0, 6).every(Number.isFinite) ? [{ x1:n[0], y1:n[1], z1:n[2], x2:n[3], y2:n[4], z2:n[5] }] : [];
      });
      setSegments(parsed);
    }).catch(() => setSegments([]));
  }, [dungeon.id]);

  const floors = useMemo(() => {
    const counts = new Map<number, number>();
    segments.forEach((s) => { const z = Math.round(((s.z1 + s.z2) / 2) / 5) * 5; counts.set(z, (counts.get(z) || 0) + 1); });
    return [...counts.entries()].sort((a,b) => b[1]-a[1]).slice(0,8).map(([z]) => z).sort((a,b)=>b-a);
  }, [segments]);
  const visible = useMemo(() => floor === 'all' ? segments : segments.filter((s) => Math.abs(((s.z1+s.z2)/2)-Number(floor)) <= 6), [segments, floor]);
  const bounds = useMemo(() => {
    const xs = visible.flatMap((s) => [s.x1,s.x2]); const ys = visible.flatMap((s) => [s.y1,s.y2]);
    if (!xs.length) return { minX:-100, minY:-100, width:200, height:200 };
    const minX=Math.min(...xs), maxX=Math.max(...xs), minY=Math.min(...ys), maxY=Math.max(...ys), pad=25;
    return { minX:minX-pad, minY:minY-pad, width:maxX-minX+pad*2, height:maxY-minY+pad*2 };
  }, [visible]);
  const shownSpawns = dungeon.spawns.filter((s) => !verifiedOnly || /User-Verified|EQL Source survey/i.test(s.source));
  const cx=bounds.minX+bounds.width/2, cy=bounds.minY+bounds.height/2;
  const viewWidth=bounds.width/zoom, viewHeight=bounds.height/zoom;

  return <section className="dossier">
    <header className="dossierhead">
      <div><small>EVIDENCE-FIRST DUNGEON REFERENCE</small><h2>Dungeon Dossiers</h2><p>Readable map geometry and sourced field intelligence—without claiming an exact 3D reconstruction.</p></div>
      <div className="dungeontabs">{DUNGEONS.map((d,i)=><button key={d.id} className={zone===i?'active':''} onClick={()=>setZone(i)}>{d.name}<span>{d.range}</span></button>)}</div>
    </header>
    <div className="dossiergrid">
      <article className="mapdossier">
        <div className="maptoolbar"><label><Layers3/> Floor <select value={floor} onChange={(e)=>setFloor(e.target.value)}><option value="all">All mapped levels</option>{floors.map((z,i)=><option key={z} value={z}>Layer {i+1} · Z≈{z}</option>)}</select></label><div><button onClick={()=>setZoom((z)=>Math.max(1,z-.25))} aria-label="Zoom out"><Minus/></button><output>{Math.round(zoom*100)}%</output><button onClick={()=>setZoom((z)=>Math.min(3,z+.25))} aria-label="Zoom in"><Plus/></button></div></div>
        <div className="dungeonmap"><svg viewBox={`${cx-viewWidth/2} ${cy-viewHeight/2} ${viewWidth} ${viewHeight}`} aria-label={`${dungeon.name} line map`}><g>{visible.map((s,i)=><line key={i} x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2}/>)}</g>{floor==='all' && shownSpawns.map((s,i)=><g className="pois" key={s.name} onClick={()=>setActive(s)} role="button" tabIndex={0} onKeyDown={(e)=>{if(e.key==='Enter')setActive(s)}}><circle cx={s.loc[0]} cy={s.loc[1]} r={Math.max(4,bounds.width/130)}/><text x={s.loc[0]} y={s.loc[1]}>{i+1}</text></g>)}</svg>{!segments.length&&<p>Map lines unavailable for this dossier.</p>}<span className="maptruth">Flattened EQL map-file geometry · markers are approximate unless individually verified</span></div>
      </article>
      <aside className="dossierintel">
        <small>DUNGEON BRIEF</small><h2>{dungeon.name}</h2><div className="rangeflag">Suggested monster range {dungeon.range}</div>
        <dl><div><dt><Route/> Adjacent</dt><dd>{notes.adjacent}</dd></div><div><dt>Layout</dt><dd>{notes.character}</dd></div><div><dt><AlertTriangle/> Dangers</dt><dd>{notes.danger}</dd></div><div><dt><MapPin/> Getting there</dt><dd>{notes.travel}</dd></div></dl>
        <label className="verifiedtoggle"><input type="checkbox" checked={verifiedOnly} onChange={(e)=>setVerifiedOnly(e.target.checked)}/><ShieldCheck/> Show stronger EQL evidence only</label>
      </aside>
    </div>
    <section className="namedindex"><header><div><small>POINTS OF INTEREST</small><h2>Named NPC intelligence</h2></div><span>{shownSpawns.length} records</span></header><div>{shownSpawns.map((s,i)=><button key={s.name} className={active?.name===s.name?'active':''} onClick={()=>setActive(s)}><b>{i+1}</b><span><strong>{s.name}</strong><small>Level {s.level} · X {s.loc[0]} · Y {s.loc[1]} · Z {s.loc[2]}</small></span><em className={`badge ${sourceClass(s.source)}`}>{s.source}</em><ChevronRight/></button>)}</div></section>
    {active&&<article className="dossierdetail"><button onClick={()=>setActive(null)} aria-label="Close NPC details">×</button><small>NAMED NPC · LEVEL {active.level}</small><h2>{active.name}</h2><dl><div><dt>Approximate /loc</dt><dd>X {active.loc[0]} · Y {active.loc[1]} · Z {active.loc[2]}</dd></div><div><dt>Reported drops</dt><dd>{active.loot}</dd></div><div><dt>Quest intelligence</dt><dd>{active.quest}</dd></div></dl><p><Eye/> {active.source}</p></article>}
  </section>;
}
