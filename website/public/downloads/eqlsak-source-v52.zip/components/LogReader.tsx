'use client';

import { useMemo, useRef, useState } from 'react';
import {
  Download,
  FileText,
  Search,
  ShieldCheck,
  Upload,
} from 'lucide-react';

type Kind = 'chat' | 'loot' | 'faction' | 'system' | 'text';
type Event = {
  id: number;
  timestamp: string;
  date: number | null;
  kind: Kind;
  actor: string;
  target: string;
  detail: string;
  raw: string;
};

const loot =
  /^(?:--)?(.+?) (?:has|have) looted (.+?)(?: from .+?)?[.!]?(?:--)?$/i;
const faction =
  /^(?:Your )?faction standing with (.+?) has gotten (better|worse)[.!]?$/i;
const chat =
  /^(?:You|(.+?)) (say|says|tell|tells|shout|shouts|auction|auctions|ooc|guild|group),? ['“](.+?)['”]$/i;

function parseDate(value: string) {
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}
function parseLog(text: string) {
  const events: Event[] = [];
  let id = 0;
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const stamped = line.match(/^\[([^\]]+)\]\s*(.*)$/),
      timestamp = stamped?.[1] || '',
      body = (stamped?.[2] || line).trim(),
      date = parseDate(timestamp);
    let m: RegExpMatchArray | null;
    if ((m = body.match(loot)))
      events.push({
        id: id++,
        timestamp,
        date,
        kind: 'loot',
        actor: m[1],
        target: m[2],
        detail: 'looted',
        raw: body,
      });
    else if ((m = body.match(faction)))
      events.push({
        id: id++,
        timestamp,
        date,
        kind: 'faction',
        actor: 'You',
        target: m[1],
        detail: m[2].toLowerCase(),
        raw: body,
      });
    else if ((m = body.match(chat)))
      events.push({
        id: id++,
        timestamp,
        date,
        kind: 'chat',
        actor: m[1] || 'You',
        target: m[2],
        detail: m[3],
        raw: body,
      });
    else if (
      /experience|entered|zone|camp|who|friend|group|guild|tell|say|auction|ooc/i.test(
        body,
      )
    )
      events.push({
        id: id++,
        timestamp,
        date,
        kind: 'system',
        actor: 'EQL',
        target: '',
        detail: body,
        raw: body,
      });
    else
      events.push({
        id: id++,
        timestamp,
        date,
        kind: 'text',
        actor: '',
        target: '',
        detail: body,
        raw: body,
      });
  }
  return events;
}
function fmt(n: number) {
  return new Intl.NumberFormat().format(n);
}
function csvCell(value: string | number) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

export default function LogReader() {
  const input = useRef<HTMLInputElement>(null),
    [events, setEvents] = useState<Event[]>([]),
    [fileName, setFileName] = useState(''),
    [query, setQuery] = useState(''),
    [kind, setKind] = useState<'all' | Kind>('all'),
    [error, setError] = useState('');
  const filtered = useMemo(
    () =>
      events.filter(
        (e) =>
          (kind === 'all' || e.kind === kind) &&
          `${e.actor} ${e.target} ${e.detail} ${e.raw}`
            .toLowerCase()
            .includes(query.toLowerCase()),
      ),
    [events, kind, query],
  );
  const totals = useMemo(
    () =>
      (['chat', 'loot', 'faction', 'system', 'text'] as Kind[]).map(
        (name) =>
          [name, events.filter((event) => event.kind === name).length] as const,
      ),
    [events],
  );
  async function choose(file?: File) {
    if (!file) return;
    setError('');
    if (file.size > 100 * 1024 * 1024) {
      setError('Choose a log smaller than 100 MB for this browser session.');
      return;
    }
    try {
      setEvents(parseLog(await file.text()));
      setFileName(file.name);
    } catch {
      setError('That file could not be read as a text log.');
    }
  }
  function exportCsv() {
    const header = [
      'timestamp',
      'type',
      'actor',
      'target',
      'detail',
      'original',
    ];
    const rows = filtered.map((e) => [
      e.timestamp,
      e.kind,
      e.actor,
      e.target,
      e.detail,
      e.raw,
    ]);
    const blob = new Blob(
        [[header, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n')],
        { type: 'text/csv;charset=utf-8' },
      ),
      url = URL.createObjectURL(blob),
      a = document.createElement('a');
    a.href = url;
    a.download =
      (fileName.replace(/\.[^.]+$/, '') || 'eql-session') + '-readable.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <section className="logdesk">
      <header className="loghero">
        <div>
          <small>LOCAL-ONLY EQL LOG READER</small>
          <h2>Turn the scroll into a field report.</h2>
          <p>
            Your selected log is parsed inside this browser tab. Its contents
            are not sent to EQLSaK or stored on the site.
          </p>
        </div>
        <button className="logpick" onClick={() => input.current?.click()}>
          <Upload />
          Choose EQL log
        </button>
        <input
          ref={input}
          type="file"
          accept=".txt,.log,text/plain"
          hidden
          onChange={(e) => choose(e.target.files?.[0])}
        />
      </header>
      <div className="logsetup">
        <strong>Choose a file that actually exists</strong>
        <span>
          Open the EQL Logs folder and select any existing readable text file:
        </span>
        <code>
          C:\Users\Public\Daybreak Game Company\Installed Games\EverQuest
          Legends\Logs
        </code>
        <em className="badge verified">User-provided EQL location</em>
      </div>
      {!events.length ? (
        <div
          className="logdrop"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            void choose(e.dataTransfer.files[0]);
          }}
        >
          <FileText />
          <h3>{error || 'Choose or drop a character log here'}</h3>
          <p>
            EQLSaK does not assume a character/server filename. If that folder
            contains a .txt or .log file, this viewer can organize its readable
            lines. If the folder contains no text log, there is nothing for the
            browser to import—and this tool cannot manufacture one.
          </p>
          <span>Nothing leaves your device.</span>
        </div>
      ) : (
        <>
          <div className="logfile">
            <span>
              <ShieldCheck />
              LOCAL PARSE
            </span>
            <b>{fileName}</b>
            <small>{fmt(events.length)} readable lines</small>
            <button onClick={() => input.current?.click()}>Change file</button>
            <button onClick={exportCsv}>
              <Download />
              Readable CSV
            </button>
          </div>
          <div className="logstats">
            {totals.map(([name, value]) => (
              <article key={name}>
                <FileText />
                <span>{name === 'text' ? 'Other text' : name}</span>
                <b>{fmt(value)}</b>
              </article>
            ))}
          </div>
          <div className="loggrid">
            <section className="logleaders">
              <small>USER-VERIFIED EQL</small>
              <h3>What this reader does</h3>
              <p>
                Reads and searches the text EQL actually records. It does not
                calculate damage, healing, DPS, or other combat statistics.
              </p>
              <p>Every non-empty line remains available under All lines.</p>
            </section>
            <section className="logevents">
              <header>
                <div className="logsearch">
                  <Search />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search names, chat, zones, or any text…"
                  />
                </div>
                <select
                  value={kind}
                  onChange={(e) => setKind(e.target.value as typeof kind)}
                >
                  <option value="all">All events</option>
                  {(
                    [
                      'loot',
                      'faction',
                      'chat',
                      'system',
                      'text',
                    ] as Kind[]
                  ).map((k) => (
                    <option key={k}>{k}</option>
                  ))}
                </select>
              </header>
              <div className="eventlist">
                {filtered
                  .slice(-500)
                  .reverse()
                  .map((e) => (
                    <article className={`event ${e.kind}`} key={e.id}>
                      <time>{e.timestamp || 'No timestamp'}</time>
                      <span>{e.kind}</span>
                      <p>{e.raw}</p>
                    </article>
                  ))}
              </div>
            </section>
          </div>
        </>
      )}
      <footer className="loglimits">
        <b>Confirmed limitation:</b> EQL does not provide the previously stated
        character/server log or combat-stat data at that location. This reader
        works only with an actual readable text file selected by the player; it
        never creates, uploads, or alters one.
      </footer>
    </section>
  );
}
