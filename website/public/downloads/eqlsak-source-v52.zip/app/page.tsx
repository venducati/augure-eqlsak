'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  BookOpen,
  ChevronDown,
  ChevronRight,
  CircleDot,
  Compass,
  Cuboid,
  Map,
  Minus,
  Plus,
  Search,
  ScrollText,
  ShieldCheck,
  Ship,
  Swords,
  UserRound,
  X,
} from 'lucide-react';
import DungeonGuide from '@/components/DungeonGuide';
import LogReader from '@/components/LogReader';

type Source =
  | 'User-Verified EQL'
  | 'EQL-specific source'
  | 'Legacy EQ unverified';
type Profile = {
  name: string;
  level: string;
  build: string;
  location: string;
  goal: string;
};
type RecordItem = {
  id: string;
  type: string;
  name: string;
  summary: string;
  source: Source;
  zone?: string;
  mob?: string;
  level?: string;
  details?: string[];
};

const connections: Record<string, string[]> = {
  'South Qeynos': ['East Freeport', 'Odus'],
  'East Freeport': [
    'South Qeynos',
    'Butcherblock Mountains',
    'East Commonlands',
  ],
  'Butcherblock Mountains': ['East Freeport', 'Greater Faydark'],
  'Greater Faydark': ['Butcherblock Mountains', 'Lesser Faydark', 'Crushbone'],
  'Lesser Faydark': ['Greater Faydark', 'Castle Mistmoore'],
  'East Commonlands': ['East Freeport', 'Nektulos Forest'],
  'Nektulos Forest': ['East Commonlands', 'Lavastorm Mountains'],
  'Lavastorm Mountains': ['Nektulos Forest', 'Najena'],
  'South Karana': ['Splitpaw Lair'],
  'Splitpaw Lair': ['South Karana'],
  'Castle Mistmoore': ['Lesser Faydark'],
  Crushbone: ['Greater Faydark'],
  Najena: ['Lavastorm Mountains'],
  Odus: ['South Qeynos'],
};

function RoutePicker({
  id,
  label,
  value,
  placeholder,
  onChange,
}: {
  id: string;
  label: string;
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [showAll, setShowAll] = useState(true);
  const matches = showAll
    ? routeStops
    : routeStops.filter((stop) =>
        stop.toLowerCase().includes(value.trim().toLowerCase()),
      );

  return (
    <label className="routepicker">
      <span>{label}</span>
      <div className="routepickercontrol">
        <input
          id={id}
          value={value}
          onChange={(event) => {
            onChange(event.target.value);
            setShowAll(false);
            setOpen(true);
          }}
          onFocus={() => {
            setShowAll(true);
            setOpen(true);
          }}
          onKeyDown={(event) => {
            if (event.key === 'Escape') setOpen(false);
            if (event.key === 'ArrowDown') setOpen(true);
          }}
          placeholder={placeholder}
          aria-label={label.replace(':', '')}
          role="combobox"
          aria-autocomplete="list"
          aria-expanded={open}
          aria-controls={`${id}-options`}
          autoComplete="off"
        />
        <button
          type="button"
          className="routepickerarrow"
          aria-label={`${open ? 'Close' : 'Open'} ${label.replace(':', '')} choices`}
          aria-expanded={open}
          aria-controls={`${id}-options`}
          onClick={() => {
            setShowAll(true);
            setOpen((current) => !current);
          }}
        >
          <ChevronDown aria-hidden="true" />
        </button>
      </div>
      {open && (
        <div className="routepickeroptions" id={`${id}-options`} role="listbox">
          {(matches.length ? matches : routeStops).map((stop) => (
            <button
              type="button"
              role="option"
              aria-selected={stop === value}
              className={stop === value ? 'selected' : ''}
              key={stop}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => {
                onChange(stop);
                setOpen(false);
              }}
            >
              {stop}
            </button>
          ))}
        </div>
      )}
    </label>
  );
}

const routeStops = Array.from(
  new Set([
    ...Object.keys(connections),
    ...Object.values(connections).flat(),
    'Halas',
    'Rivervale',
    'Kaladim',
    'Kelethin',
    'Felwithe',
    'Ak’Anon',
    'Neriak',
    'Grobb',
    'Oggok',
    'Erudin',
    'Erudin Palace',
    'Paineel',
    'Cabilis',
    'West Cabilis',
  ]),
).sort((a, b) => a.localeCompare(b));

const vendorDirectory = [
  ['Halas', 'Cindl', 'Large leather armor and tailoring patterns', 'McPherson district'],
  ['Halas', 'April', 'Weapons and adventuring supplies', "McPherson's Bloody Blades"],
  ['Halas', 'Brin McQuaid', 'Ale and tavern supplies', "McQuaid's Dark Stout"],
  ['South Qeynos', 'Hanlore Escaval', 'Caster supplies and spells', 'The Herb Jar'],
  ['South Qeynos', 'Tasya Huntlan', 'Ale and brewing supplies', "Lion's Mane Inn"],
  ['South Qeynos', 'McNeal Jocub', 'Food and drink', "Fish's Ale tavern"],
  ['East Freeport', 'Klan Smith', 'Weapons', 'East Freeport smithy'],
  ['East Freeport', 'Gord Smith', 'Weapons', 'East Freeport smithy'],
  ['East Freeport', 'Celanie Xtoria', 'Weapons and supplies', 'East Freeport market'],
  ['Rivervale', 'Alice Sweetoven', 'Food and baking supplies', 'Rivervale village'],
  ['Rivervale', 'Flyndia Deeppockets', 'Rogue supplies', "Fool's Gold, first floor"],
  ['Rivervale', 'Fiddy Bobick', 'General goods', 'Dockside shop'],
  ['Kelethin', 'Merchant Niwiny', 'Smithing molds and patterns', 'Kelethin platforms'],
  ['Kelethin', 'Merchant Gililya', 'Rogue supplies', 'Rogue Guild platform'],
  ['Kelethin', 'Merchant Tuluvdar', 'Ranger supplies', 'Ranger Guild platform'],
  ['Kaladim', 'Aarina Ratsbone', 'Bags and containers', 'Southeast Kaladim'],
  ['Kaladim', 'Alanury Stormhammer', 'Fletching supplies', 'South Kaladim'],
  ['Kaladim', 'Didek Stormhammer', 'Weapons', 'South Kaladim'],
  ['Felwithe', 'Merchant Dantree', 'Weapons', 'Felwithe shops'],
  ['Felwithe', 'Tylar Windspirit', 'Weapons and supplies', 'Felwithe shops'],
  ['Felwithe', 'Isyna Firspanyl', 'Weapons and supplies', 'Felwithe shops'],
  ["Ak’Anon", 'A Clockwork Weaponsmith', 'Weapons', "Ak’Anon forge district"],
  ["Ak’Anon", 'A Clockwork Grocer', 'Food and drink', "Ak’Anon market"],
  ["Ak’Anon", 'A Clockwork Jeweler', 'Jewelcraft supplies', "Ak’Anon bank district"],
  ['Erudin', 'Ayth Niphiria', 'Weapons', 'Erudin shops'],
  ['Erudin', 'Teria Finleather', 'Leather armor and supplies', 'Erudin Surplus'],
  ['Erudin', 'Syra Printell', 'Cleric spells', 'Erudin temple district'],
  ['Erudin Palace', 'Anite Gemcutter', 'Gems and jewelcraft supplies', 'Palace basement'],
  ['Erudin Palace', 'Myrcin Denuen', 'General and caster supplies', 'Palace basement'],
  ['Erudin Palace', 'Agryn Moonfield', 'General goods', 'Palace upper district'],
  ['Paineel', 'Rallia Hapera', 'Key and general supplies', 'Superior Supplies near bank'],
  ['Paineel', 'Zarnlel Apridor', 'Cleric spells', 'Paineel guild district'],
  ['Paineel', 'Keletha Nightweaver', 'Caster supplies', 'Paineel market'],
] as const;

const vendorRecords: RecordItem[] = vendorDirectory.map(
  ([city, name, goods, location], index) => ({
    id: `vendor-${index}`,
    type: 'Vendor',
    name,
    summary: `${goods} · ${city}`,
    source: 'Legacy EQ unverified',
    zone: city,
    details: [
      `City: ${city}`,
      `Known location: ${location}`,
      `Known wares: ${goods}`,
      'Classic-era vendor record; verify NPC name, inventory, faction access, and coordinates in EQL.',
    ],
  }),
);

const records: RecordItem[] = [
  ...vendorRecords,
  {
    id: 'clear-gem',
    type: 'Command',
    name: '/memspellslot <slot> 0',
    summary:
      'Clears one memorized spell gem. The trailing zero is the deletion value.',
    source: 'User-Verified EQL',
    details: [
      'Repeat for each occupied slot.',
      'Slots 1–14 are possible with the relevant AA Archetype perk.',
      'With five-line socials, use three buttons: 1–5, 6–10, 11–14.',
    ],
  },
  {
    id: 'faction-command',
    type: 'Command',
    name: '/faction',
    summary: 'Exposes exact faction values in EQL.',
    source: 'User-Verified EQL',
    details: [
      'Prefer measured values over con-message estimates.',
      'Record before and after a turn-in to verify its exact delta.',
    ],
  },
  {
    id: 'fish-macro',
    type: 'Command',
    name: 'One-tap fishing social',
    summary:
      '/autoinventory followed by /doability Fishing. Re-press after the cooldown.',
    source: 'EQL-specific source',
    details: [
      'EQL socials do not provide true loops or conditionals.',
      'Ordinary bait stays in inventory; it is not attached to the pole.',
    ],
  },
  {
    id: 'inventory-output',
    type: 'Command',
    name: '/out inventory',
    summary:
      'Exports inventory data for sortable companion tools; it does not rearrange bags.',
    source: 'EQL-specific source',
  },
  {
    id: 'wood-elf',
    type: 'Race',
    name: 'Wood Elf',
    summary:
      'Forest people of Greater Faydark, closely associated with Kelethin and the living canopy.',
    source: 'Legacy EQ unverified',
    zone: 'Greater Faydark',
  },
  {
    id: 'high-elf',
    type: 'Race',
    name: 'High Elf',
    summary:
      'Arcane and clerical culture centered on Felwithe in the eastern Faydwer forests.',
    source: 'Legacy EQ unverified',
    zone: 'Greater Faydark',
  },
  {
    id: 'dwarf',
    type: 'Race',
    name: 'Dwarf',
    summary: 'Mountain and forge culture of Kaladim in Butcherblock Mountains.',
    source: 'Legacy EQ unverified',
    zone: 'Butcherblock Mountains',
  },
  {
    id: 'human',
    type: 'Race',
    name: 'Human',
    summary:
      'A varied people whose major Antonican centers include Qeynos and Freeport.',
    source: 'Legacy EQ unverified',
    zone: 'South Qeynos',
  },
  {
    id: 'dark-elf',
    type: 'Race',
    name: 'Dark Elf',
    summary:
      'The Teir’Dal people of Neriak, rooted in the shadowed forests of eastern Antonica.',
    source: 'Legacy EQ unverified',
    zone: 'Nektulos Forest',
  },
  {
    id: 'barbarian',
    type: 'Race',
    name: 'Barbarian',
    summary:
      'Northern highland people associated with Halas and the Everfrost frontier.',
    source: 'Legacy EQ unverified',
  },
  {
    id: 'iksar',
    type: 'Race',
    name: 'Iksar',
    summary:
      'Scaled people of Kunark, with Cabilis and the ancient jungle empire at the heart of their story.',
    source: 'Legacy EQ unverified',
  },
  {
    id: 'mistmoore',
    type: 'Zone',
    name: 'Castle Mistmoore',
    summary: 'Revamped dungeon reached only through southwest Lesser Faydark.',
    source: 'EQL-specific source',
    zone: 'Castle Mistmoore',
    level: '20–45',
    details: [
      'Entrance/courtyard is roughly 20–30.',
      'Mistmoore-side exit is approximately /loc -295, 123.',
      'Use invisibility across Lesser Faydark when possible.',
    ],
  },
  {
    id: 'najena',
    type: 'Zone',
    name: 'Najena',
    summary:
      'Revamped 15–30 dungeon in southeast Lavastorm, behind shattered doors.',
    source: 'EQL-specific source',
    zone: 'Najena',
    level: '15–30',
    details: [
      'Druid port to Lavastorm is the fastest approach.',
      'Najena exit to Lavastorm is around /loc -13, 856.',
    ],
  },
  {
    id: 'splitpaw',
    type: 'Zone',
    name: 'Splitpaw Lair',
    summary: 'Long progression runway for XP and gear, beginning at level 25.',
    source: 'EQL-specific source',
    zone: 'Splitpaw Lair',
    level: '25–42',
  },
  {
    id: 'upper-guk',
    type: 'Zone',
    name: 'Upper Guk',
    summary:
      'At 25–30 consider barracks/Shin Lord or saltwater/Ancient Crocodile.',
    source: 'EQL-specific source',
    zone: 'Upper Guk',
    level: '10–30',
  },
  {
    id: 'cazic',
    type: 'Zone',
    name: 'Cazic-Thule',
    summary:
      'Alligator Pit is a useful 25–31 option; watch roamers and healers.',
    source: 'EQL-specific source',
    zone: 'Cazic-Thule',
    level: '25–31',
  },
  {
    id: 'unrest',
    type: 'Zone',
    name: 'Estate of Unrest',
    summary: 'Fireplace camp is a practical 19–26 dungeon stop.',
    source: 'EQL-specific source',
    zone: 'Estate of Unrest',
    level: '19–26',
  },
  {
    id: 'crocpants',
    type: 'Item',
    name: 'Ancient Crocodile WIS pants',
    summary: 'Sought-after wisdom leg drop used to pair XP with progression.',
    source: 'EQL-specific source',
    zone: 'Upper Guk',
    mob: 'Ancient Crocodile',
    level: '25–30',
  },
  {
    id: 'baron',
    type: 'NPC',
    name: "Baron Telyx V'Zher",
    summary:
      'Roughly level 28 dark elf paladin in Befallen. EQL respawn is not confirmed.',
    source: 'Legacy EQ unverified',
    zone: 'Befallen',
    level: '28',
    details: [
      'Approximate location: /loc -1002, -70.',
      'Treat 15–20 minutes only as a working estimate until timed in EQL.',
    ],
  },
  {
    id: 'tiam',
    type: 'NPC',
    name: 'Tiam Khonsir',
    summary:
      'Deepwater Knights molar turn-in NPC. Erudite illusion produced Amiable.',
    source: 'User-Verified EQL',
    zone: 'Erudin',
    details: [
      'Dialogue: “Yes” then “I have come to serve our lord.”',
      'Test with one molar before committing a stockpile.',
    ],
  },
  {
    id: 'molars',
    type: 'Faction',
    name: 'Kobold Molars (Good)',
    summary:
      'Per molar: Deepwater Knights +7, High Council +5, Heretics −1, Kerra Isle −1.',
    source: 'EQL-specific source',
    zone: 'Erudin',
    mob: 'Tiam Khonsir',
  },
  {
    id: 'slansin',
    type: 'Quest',
    name: 'Inert Potion → *Slansin',
    summary:
      'Non-merchant Slansin Denvin accepts the potion stockpile for Freeport Militia gains.',
    source: 'EQL-specific source',
    zone: 'Erudin',
    details: [
      'Merchant version is the wrong spawn; one potion despawns it.',
      'Each successful Denvin potion is listed as +1 Freeport Militia and several allied factions.',
    ],
  },
  {
    id: 'elial',
    type: 'NPC',
    name: 'Elial Brook',
    summary:
      'Level 7 faction target at approximately /loc 161, 1164 in Toxxulia.',
    source: 'Legacy EQ unverified',
    zone: 'Toxxulia Forest',
    level: '7',
    details: [
      'Legacy listing: +20 Deepwater Knights and three allied caster factions; −20 Heretics.',
      'Respawn/chance and faction values still need direct EQL verification.',
    ],
  },
  {
    id: 'shmbrd',
    type: 'Build',
    name: 'SHM / BRD sustain build',
    summary:
      'Balanced + Recovery for normal grinding; Shaman handles slow, DoTs, heals and buffs.',
    source: 'EQL-specific source',
    details: [
      'Test Offensive + Recovery on safe blues/whites.',
      'Use Evasive as a short emergency defense while endurance lasts.',
      'Bard supplies passive songs, sustain and utility.',
    ],
  },
  {
    id: 'mce',
    type: 'Build',
    name: 'MNK / CLR / ENC utility build',
    summary:
      'Melee delivery with Cleric sustain and Enchanter control; organize classes across extra hotbars.',
    source: 'EQL-specific source',
  },
  {
    id: 'faydwer-route',
    type: 'Route',
    name: 'Qeynos → Faydwer',
    summary:
      'South Qeynos docks → East Freeport docks → Butcherblock Mountains.',
    source: 'EQL-specific source',
    zone: 'Butcherblock Mountains',
  },
  {
    id: 'kunark-continent',
    type: 'Zone',
    name: 'Kunark',
    summary: 'Search hub for Kunark cities, wilderness zones, and dungeons.',
    source: 'User-Verified EQL',
    details: [
      'Kunark has been added to the companion place index at the user’s request.',
      'Individual location details remain explicitly marked until verified in EQL.',
    ],
  },
  ...([
    ['Cabilis', 'East Cabilis, West Cabilis, Cab'],
    ['Field of Bone', 'FoB'],
    ["Kurn’s Tower", 'Kurns, Kurn'],
    ["Warslik’s Woods", 'WW, Warsliks'],
    ['Lake of Ill Omen', 'LOIO, Lake'],
    ['Swamp of No Hope', 'SoNH, Swamp'],
    ['Firiona Vie', 'FV'],
    ['The Overthere', 'OT, Overthere'],
    ['Frontier Mountains', 'FM'],
    ['Dreadlands', 'DL'],
    ['Burning Wood', 'BW'],
    ['Skyfire Mountains', 'Skyfire'],
    ['Emerald Jungle', 'EJ'],
    ["Trakanon’s Teeth", 'TT, Trakanons Teeth'],
    ['City of Mist', 'CoM'],
    ['Kaesora', 'Kaes'],
    ['Crypt of Dalnir', 'Dalnir'],
    ["Karnor’s Castle", 'KC, Karnors'],
    ['Old Sebilis', 'Seb, Sebilis'],
    ['Chardok', 'Chardok'],
    ['Temple of Droga', 'Droga'],
    ['Mines of Nurga', 'Nurga'],
    ['Howling Stones', 'HS, Charasis'],
    ["Veeshan’s Peak", 'VP'],
    ['Timorous Deep', 'TD'],
  ] as const).map(([name, aliases], index): RecordItem => ({
    id: `kunark-place-${index}`,
    type: 'Zone',
    name,
    summary: `Kunark location. Common search names: ${aliases}.`,
    source: 'Legacy EQ unverified',
    zone: name,
    details: [
      'Included in the Kunark place index for fast searching.',
      'Zone details, routes, and level guidance still require EQL-specific verification.',
    ],
  })),
];

const fieldSections = [
  { name: 'World Maps & Zones', types: ['Zone'] },
  { name: 'How-To Commands', types: ['Command'] },
  { name: 'Travel Routes', types: ['Route'] },
  { name: 'Races & Starting Locations', types: ['Race'] },
  { name: 'Named NPCs & Quests', types: ['NPC', 'Quest'] },
  { name: 'Loot & Items', types: ['Item'] },
  { name: 'Faction Mechanics', types: ['Faction'] },
  { name: 'Character Builds', types: ['Build'] },
] as const;

const defaultProfiles: Profile[] = [
  {
    name: 'You',
    level: '25',
    build: 'SHM / BRD',
    location: 'Castle Mistmoore',
    goal: 'XP + useful gear',
  },
  { name: 'Friend', level: '', build: '', location: '', goal: '' },
];
const zonePoints = [
  ['Butcherblock Mountains', 22, 52],
  ['Greater Faydark', 39, 35],
  ['Lesser Faydark', 55, 48],
  ['Castle Mistmoore', 73, 62],
  ['Najena', 84, 27],
  ['Splitpaw Lair', 61, 81],
] as const;
const realms = [
  {
    name: 'Faydwer',
    subtitle: 'The elder forest realms',
    races: ['Wood Elf', 'High Elf', 'Dwarf'],
    places: 'Kelethin · Felwithe · Kaladim',
    image: '/art/faydwer-races.png',
    tone: 'gold',
  },
  {
    name: 'Antonica',
    subtitle: 'Coasts, kingdoms & northern wilds',
    races: ['Human', 'Dark Elf', 'Barbarian'],
    places: 'Qeynos · Freeport · Halas · Neriak',
    image: '/art/antonica-races.png',
    tone: 'steel',
  },
  {
    name: 'Kunark',
    subtitle: 'The ancient scaled empire',
    races: ['Iksar'],
    places: 'Cabilis · Field of Bone · Emerald Jungle',
    image: '/art/kunark-races.png',
    tone: 'jade',
  },
] as const;
const atlasMaps = [
  {
    name: 'Antonica',
    image: '/art/map-antonica.png',
    subtitle: 'The old world · western kingdoms to eastern wastes',
    nodes: [
      ['Everfrost Peaks', 15, 13, '1–35', 'wild'],
      ['Halas', 20, 17, '1–10', 'city'],
      ['Blackburrow', 22, 28, '5–15', 'dungeon'],
      ['Qeynos Hills', 24, 38, '1–10', 'wild'],
      ['South Qeynos', 17, 44, '1–10', 'city'],
      ['West Karana', 35, 42, '10–20', 'wild'],
      ['Highpass Hold', 47, 33, '15–25', 'dungeon'],
      ['East Commonlands', 66, 41, '5–20', 'wild'],
      ['East Freeport', 82, 45, '1–10', 'city'],
      ['Nektulos Forest', 76, 30, '5–20', 'wild'],
      ['Lavastorm Mtns.', 87, 22, '10–30', 'wild'],
      ['Najena', 91, 27, '15–30', 'dungeon'],
      ['North Ro', 79, 57, '5–20', 'wild'],
      ['Oasis of Marr', 73, 65, '10–25', 'wild'],
      ['South Ro', 73, 76, '15–30', 'wild'],
      ['Innothule Swamp', 52, 79, '1–20', 'wild'],
      ['Upper Guk', 57, 73, '10–30', 'dungeon'],
      ['Lower Guk', 61, 78, '30–50', 'dungeon'],
      ['The Feerrott', 43, 83, '10–35', 'wild'],
      ['Cazic-Thule', 39, 88, '25–40', 'dungeon'],
      ['South Karana', 43, 57, '15–35', 'wild'],
      ['Splitpaw Lair', 47, 63, '25–42', 'dungeon'],
      ['Rivervale', 58, 46, '1–15', 'city'],
      ['Runnyeye', 54, 39, '15–30', 'dungeon'],
      ['Befallen', 70, 48, '5–30', 'dungeon'],
      ['Solusek’s Eye', 84, 34, '20–40', 'dungeon'],
    ],
  },
  {
    name: 'Faydwer',
    image: '/art/map-faydwer.png',
    subtitle: 'Elven forests · dwarven mountains · haunted south',
    nodes: [
      ['Butcherblock Mtns.', 19, 43, '1–20', 'wild'],
      ['Kaladim', 15, 51, '1–10', 'city'],
      ['Ocean of Tears Dock', 24, 76, 'Travel', 'travel'],
      ['Greater Faydark', 47, 46, '1–15', 'wild'],
      ['Kelethin', 49, 42, '1–10', 'city'],
      ['Crushbone', 44, 28, '5–20', 'dungeon'],
      ['Felwithe', 72, 38, '1–10', 'city'],
      ['Lesser Faydark', 51, 67, '10–25', 'wild'],
      ['Castle Mistmoore', 42, 80, '20–45', 'dungeon'],
      ['Estate of Unrest', 57, 18, '10–30', 'dungeon'],
      ['Steamfont Mtns.', 78, 74, '1–25', 'wild'],
      ['Ak’Anon', 83, 78, '1–10', 'city'],
    ],
  },
  {
    name: 'Odus',
    image: '/art/map-odus.png',
    subtitle: 'Erudite isles · Toxxulia · the Paineel divide',
    nodes: [
      ['Erudin', 76, 22, '1–10', 'city'],
      ['Erudin Palace', 80, 17, '1–10', 'city'],
      ['Toxxulia Forest', 50, 34, '1–15', 'wild'],
      ['Kerra Isle', 87, 54, '10–25', 'wild'],
      ['Erud’s Crossing', 91, 72, 'Travel', 'travel'],
      ['Paineel', 26, 68, '1–10', 'city'],
      ['The Hole', 31, 72, '40–60', 'dungeon'],
      ['Stonebrunt Mtns.', 43, 18, '25–40', 'wild'],
    ],
  },
] as const;

const atlasAliases: Record<string, string[]> = {
  Antonica: ['antonnica', 'old world'],
  'Everfrost Peaks': ['everfrost', 'ef'],
  Blackburrow: ['bb'],
  'Qeynos Hills': ['qeynos', 'qhills', 'qh'],
  'South Qeynos': ['qeynos', 'qeynos city', 'sqeynos'],
  'West Karana': ['wk', 'western karana'],
  'Highpass Hold': ['highpass', 'hph'],
  'East Commonlands': ['ec', 'east commons', 'commonlands'],
  'East Freeport': ['freeport', 'efp'],
  'Nektulos Forest': ['nek', 'nektulos'],
  'Lavastorm Mtns.': ['lavastorm', 'lavastorm mountains', 'ls'],
  'North Ro': ['nro', 'northern desert of ro'],
  'Oasis of Marr': ['oasis'],
  'South Ro': ['sro', 'southern desert of ro'],
  'Innothule Swamp': ['innothule'],
  'Upper Guk': ['uguk', 'guk top'],
  'Lower Guk': ['lguk', 'guk bottom'],
  'The Feerrott': ['feerrott'],
  'Cazic-Thule': ['ct', 'cazic thule'],
  'South Karana': ['sk'],
  'Splitpaw Lair': ['splitpaw', 'paw'],
  Runnyeye: ['runny eye'],
  'Solusek’s Eye': ['solusek eye', 'sol a', 'sola'],
};

type DropSighting = {
  mob: string;
  seen: number;
  off_roster: boolean;
  sessions: Array<{
    date: string;
    zone: string | null;
    difficulty: number;
  }>;
};

type LootIndexItem = {
  name: string;
  sightings: DropSighting[];
};

const EQL_SOURCE_DROPS =
  'https://eqlsource.com/data/sightings.v1.json';
const EQL_SOURCE_INDEX = 'https://www.eqlsource.com/tools/index-search';
const EQLBASE_ITEMS = 'https://eqlbase.com/items/';

function normalizeSearch(value: string) {
  return value
    .toLowerCase()
    .replace(/[’']/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function provenanceClass(source: Source) {
  return source === 'User-Verified EQL'
    ? 'verified'
    : source === 'EQL-specific source'
      ? 'eql'
      : 'legacy';
}
function routeBetween(from: string, to: string) {
  if (!from || !to || from === to) return from ? [from] : [];
  const queue = [[from]],
    seen = new Set([from]);
  while (queue.length) {
    const path = queue.shift()!;
    for (const next of connections[path.at(-1)!] || []) {
      if (next === to) return [...path, next];
      if (!seen.has(next)) {
        seen.add(next);
        queue.push([...path, next]);
      }
    }
  }
  return [];
}

export default function Home() {
  const [tab, setTab] = useState('Quick');
  const [query, setQuery] = useState('');
  const [profiles, setProfiles] = useState(defaultProfiles);
  const [active, setActive] = useState(0);
  const [selected, setSelected] = useState<RecordItem | null>(null);
  const [from, setFrom] = useState('East Freeport');
  const [to, setTo] = useState('Castle Mistmoore');
  const [edit, setEdit] = useState(false);
  const [realm, setRealm] = useState(0);
  const [atlas, setAtlas] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [mapType, setMapType] = useState('all');
  const [vendorCity, setVendorCity] = useState<string | null>(null);
  const [selectedInstance, setSelectedInstance] = useState('Castle Mistmoore');
  const [searchFeedback, setSearchFeedback] = useState('');
  const [levelInput, setLevelInput] = useState('');
  const [advisorLevel, setAdvisorLevel] = useState<number | null>(null);
  const [lootIndex, setLootIndex] = useState<LootIndexItem[]>([]);
  const [lootIndexState, setLootIndexState] = useState<
    'loading' | 'ready' | 'unavailable'
  >('loading');
  const profile = profiles[active];
  useEffect(() => {
    const saved = localStorage.getItem('eql-profiles');
    if (saved)
      try {
        setProfiles(JSON.parse(saved));
      } catch {}
  }, []);
  useEffect(() => {
    localStorage.setItem('eql-profiles', JSON.stringify(profiles));
  }, [profiles]);
  useEffect(() => {
    setLevelInput(profile?.level || '');
    setAdvisorLevel(null);
  }, [active, profile?.level]);
  useEffect(() => {
    let cancelled = false;
    fetch(EQL_SOURCE_DROPS)
      .then((response) => {
        if (!response.ok) throw new Error('Loot index request failed');
        return response.json();
      })
      .then((payload: unknown) => {
        if (cancelled) return;
        const items = (payload as { data?: { items?: unknown } })?.data?.items;
        if (!items || typeof items !== 'object') {
          throw new Error('Loot index format was not recognised');
        }
        setLootIndex(
          Object.entries(items).map(([name, sightings]) => ({
            name,
            sightings: Array.isArray(sightings)
              ? (sightings as DropSighting[])
              : [],
          })),
        );
        setLootIndexState('ready');
      })
      .catch(() => {
        if (!cancelled) setLootIndexState('unavailable');
      });
    return () => {
      cancelled = true;
    };
  }, []);
  const results = useMemo(
    () =>
      records.filter((r) =>
        `${r.name} ${r.type} ${r.summary} ${r.zone || ''} ${r.mob || ''}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [query],
  );
  const mappedSearchResults = useMemo(() => {
    const term = normalizeSearch(query);
    if (!term) return [];
    return atlasMaps
      .flatMap((map, mapIndex) => [
        {
          mapIndex,
          name: map.name,
          level: 'CONTINENT',
          kind: 'continent',
        },
        ...map.nodes.map((node) => ({
          mapIndex,
          name: node[0],
          level: node[3],
          kind: node[4],
        })),
      ])
      .map((place) => {
        const searchable = [place.name, ...(atlasAliases[place.name] || [])].map(
          normalizeSearch,
        );
        const rank = searchable.includes(term)
          ? 0
          : searchable.some((value) => value.startsWith(term))
            ? 1
            : searchable.some((value) => value.includes(term))
              ? 2
              : 99;
        return { ...place, rank };
      })
      .filter((place) => place.rank < 99)
      .sort((a, b) => a.rank - b.rank || a.name.localeCompare(b.name));
  }, [query]);
  const lootSearchResults = useMemo(() => {
    const term = normalizeSearch(query);
    if (!term) return [];
    return lootIndex
      .map((item) => {
        const itemName = normalizeSearch(item.name);
        const related = item.sightings.flatMap((sighting) => [
          sighting.mob,
          ...sighting.sessions.map((session) => session.zone || ''),
        ]);
        const relatedMatch = related.some((value) =>
          normalizeSearch(value).includes(term),
        );
        const rank =
          itemName === term
            ? 0
            : itemName.startsWith(term)
              ? 1
              : itemName.includes(term)
                ? 2
                : relatedMatch
                  ? 3
                  : 99;
        return { ...item, rank };
      })
      .filter((item) => item.rank < 99)
      .sort((a, b) => a.rank - b.rank || a.name.localeCompare(b.name));
  }, [lootIndex, query]);
  const levelRecommendations = useMemo(() => {
    if (advisorLevel === null) return [];
    return atlasMaps
      .flatMap((map, mapIndex) =>
        map.nodes.map(([name, , , range, kind]) => ({
          name,
          mapIndex,
          range,
          kind,
        })),
      )
      .filter((place) => place.kind === 'wild' || place.kind === 'dungeon')
      .map((place) => {
        const match = String(place.range).match(/(\d+)\s*[–-]\s*(\d+)/);
        const min = match ? Number(match[1]) : 0;
        const max = match ? Number(match[2]) : 0;
        const inRange = advisorLevel >= min && advisorLevel <= max;
        const edgeDistance =
          advisorLevel < min ? min - advisorLevel : advisorLevel - max;
        const midpointDistance = Math.abs(advisorLevel - (min + max) / 2);
        const score = inRange ? midpointDistance : 100 + edgeDistance;
        return { ...place, min, max, inRange, edgeDistance, score };
      })
      .filter((place) => place.inRange || place.edgeDistance <= 3)
      .sort(
        (a, b) =>
          Number(b.inRange) - Number(a.inRange) ||
          a.score - b.score ||
          (a.kind === 'dungeon' ? -1 : 1),
      )
      .slice(0, 6);
  }, [advisorLevel]);
  const visible = query
    ? results
    : records.filter((r) =>
        tab === 'Quick'
          ? ['Command', 'Zone', 'Build'].includes(r.type)
          : tab === 'Atlas'
            ? ['Zone', 'Route', 'NPC'].includes(r.type)
            : tab === 'Loot'
              ? ['Item', 'NPC', 'Quest'].includes(r.type)
              : true,
      );
  const groupedVisible = fieldSections
    .map((section) => ({
      ...section,
      items: visible.filter((record) =>
        (section.types as readonly string[]).includes(record.type),
      ),
    }))
    .filter((section) => section.items.length);
  const route = routeBetween(from, to);
  function updateProfile(key: keyof Profile, value: string) {
    setProfiles((p) =>
      p.map((x, i) => (i === active ? { ...x, [key]: value } : x)),
    );
  }
  function openMappedLocation(place: (typeof mappedSearchResults)[number]) {
    setAtlas(place.mapIndex);
    setMapType('all');
    setTab('Atlas');
    setSearchFeedback('');
  }
  function openRecord(record: RecordItem) {
    if (record.type === 'Vendor' && record.zone) {
      const mapIndex = atlasMaps.findIndex((map) =>
        map.nodes.some(([name, , , , kind]) => kind === 'city' && name === record.zone),
      );
      if (mapIndex >= 0) {
        setAtlas(mapIndex);
        setMapType('all');
        setVendorCity(record.zone);
        setSelected(record);
        setTab('Atlas');
        setQuery('');
        setSearchFeedback('');
        return;
      }
    }
    setSelected(record);
  }
  function submitSearch(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const term = query.trim().toLowerCase();
    if (!term) {
      setSearchFeedback('Type a zone, item, NPC, command, or faction first.');
      return;
    }
    const exactLoot = lootSearchResults.find(
      (item) => normalizeSearch(item.name) === normalizeSearch(query),
    );
    if (exactLoot) {
      setSearchFeedback('');
      setTab('Loot');
      return;
    }
    const mappedZone = mappedSearchResults[0];
    if (mappedZone) {
      openMappedLocation(mappedZone);
      return;
    }
    const bestMatch =
      results.find((record) => record.name.toLowerCase() === term) ||
      results.find((record) => record.name.toLowerCase().startsWith(term)) ||
      results.find((record) => record.name.toLowerCase().includes(term)) ||
      results[0];
    if (bestMatch) {
      setSearchFeedback('');
      openRecord(bestMatch);
      return;
    }
    setTab('Loot');
    setSearchFeedback(
      `No measured EQL drop found for “${query.trim()}”. The complete baseline catalog links below may still contain it.`,
    );
  }
  function submitLevelAdvisor(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const level = Number(levelInput);
    if (!Number.isInteger(level) || level < 1 || level > 60) {
      setAdvisorLevel(null);
      return;
    }
    setAdvisorLevel(level);
  }

  return (
    <main className="min-h-screen pb-14">
      <header className="topbar">
        <div className="brand">
          <span className="brandmark" style={{ width: 58, fontSize: 9 }}>
            EQLSaK
          </span>
          <div>
            <strong>EQL Swiss Army Knife</strong>
            <small>EQLSaK · Field Companion</small>
          </div>
        </div>
        <button className="session" onClick={() => setTab('Quick')}>
          <span className="pulse" />
          PLAY SESSION
        </button>
      </header>
      <output className="prerelease">
        <strong>PRIVATE PRE-RELEASE</strong>
        <span>Unofficial community companion · Verified EQL evidence outranks legacy data</span>
      </output>
      <section className="shell">
        <aside className="rail">
          <nav aria-label="Primary">
            {([
              ['Quick', Compass],
              ['Atlas', Map],
              ['Instances', Cuboid],
              ['Loot', Swords],
              ['Logs', ScrollText],
              ['Manual', BookOpen],
            ] as const).map(([name, Icon]) => (
              <button
                key={String(name)}
                className={tab === name ? 'navactive' : ''}
                onClick={() => setTab(String(name))}
              >
                <Icon />
                {name}
              </button>
            ))}
          </nav>
          <div className="profilebox">
            <small>ACTIVE PLAYER</small>
            {profiles.map((p, i) => (
              <button
                key={p.name}
                className={active === i ? 'profileactive' : ''}
                onClick={() => setActive(i)}
              >
                <UserRound />
                {p.name}
                <span>
                  {p.build && p.level ? `${p.level} ${p.build}` : 'Add build'}
                </span>
              </button>
            ))}
          </div>
        </aside>
        <div className="workspace">
          <div className="eyebrow">
            {tab === 'Quick' ? 'LIVE FIELD DESK' : tab.toUpperCase()} ·{' '}
            {profile.name.toUpperCase()}
          </div>
          <h1>
            {tab === 'Quick' ? (
              <>
                What do you need <em>right now?</em>
              </>
            ) : tab === 'Atlas' ? (
              <>
                Find the <em>way through.</em>
              </>
            ) : tab === 'Instances' ? (
              <>
                Know every <em>corridor.</em>
              </>
            ) : tab === 'Loot' ? (
              <>
                Follow every <em>drop.</em>
              </>
            ) : tab === 'Logs' ? (
              <>
                Read every <em>adventure.</em>
              </>
            ) : (
              <>
                The trusted <em>field manual.</em>
              </>
            )}
          </h1>
          {tab !== 'Logs' && (
            <form className="search" onSubmit={submitSearch}>
              <Search />
              <input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSearchFeedback('');
                }}
                aria-label="Search EQL field records"
                placeholder="Search a zone, vendor, item, mob, command, faction…"
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => {
                    setQuery('');
                    setSearchFeedback('');
                  }}
                >
                  <X />
                </button>
              )}
              <button type="submit" aria-label="Open best search match">
                <ChevronRight />
              </button>
            </form>
          )}
          {tab !== 'Logs' && searchFeedback && (
            <output className="searchfeedback">
              {searchFeedback}
            </output>
          )}
          {tab === 'Quick' && (
            <div className="chips">
              <form
                className="quickroute"
                onSubmit={(event) => {
                  event.preventDefault();
                  if (!routeStops.includes(from) || !routeStops.includes(to)) {
                    setSearchFeedback('Choose both route locations from the suggested EQL map stops.');
                    return;
                  }
                  setSearchFeedback('');
                  const destination = atlasMaps.findIndex((map) =>
                    map.nodes.some(([name]) => name === to),
                  );
                  if (destination >= 0) setAtlas(destination);
                  setMapType('all');
                  setTab('Atlas');
                }}
              >
                <RoutePicker id="quick-route-from" label="Route From:" value={from} placeholder="Starting city or zone" onChange={setFrom} />
                <RoutePicker id="quick-route-to" label="Route To:" value={to} placeholder="Destination city or zone" onChange={setTo} />
                <button type="submit">Show route</button>
              </form>
              <button
                onClick={() => {
                  setTab('Loot');
                  setQuery('');
                }}
              >
                Loot near me
              </button>
              <button onClick={() => setEdit(!edit)}>
                Edit {profile.name}
              </button>
            </div>
          )}
          {tab === 'Quick' && (
            <section className="leveladvisor">
              <form onSubmit={submitLevelAdvisor}>
                <label htmlFor="adventure-level">Where should I go at level…</label>
                <div>
                  <input
                    id="adventure-level"
                    type="number"
                    min="1"
                    max="60"
                    inputMode="numeric"
                    value={levelInput}
                    onChange={(event) => setLevelInput(event.target.value)}
                    placeholder="Level"
                    aria-describedby="level-advisor-help"
                  />
                  <button type="submit">Find places</button>
                </div>
                <small id="level-advisor-help">Enter a whole level from 1 to 60.</small>
              </form>
              {advisorLevel !== null && (
                <div className="levelresults" aria-live="polite">
                  <header>
                    <div>
                      <small>LEVEL {advisorLevel} FIELD PICKS</small>
                      <h2>Best mapped places right now</h2>
                    </div>
                    <span>{levelRecommendations.length} matches</span>
                  </header>
                  {levelRecommendations.length ? (
                    <div>
                      {levelRecommendations.map((place) => (
                        <button
                          key={`${place.mapIndex}-${place.name}`}
                          onClick={() => {
                            setAtlas(place.mapIndex);
                            setMapType('all');
                            setTab('Atlas');
                            setSearchFeedback('');
                          }}
                        >
                          <b>{place.name}</b>
                          <span>
                            {atlasMaps[place.mapIndex].name} · {place.range} ·{' '}
                            {place.kind === 'dungeon' ? 'Dungeon' : 'Outdoor'}
                          </span>
                          <em>{place.inRange ? 'Strong match' : 'Stretch option'}</em>
                          <ChevronRight />
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p>No mapped level band matches yet. Try a nearby level.</p>
                  )}
                  <p className="advisorpolicy">
                    Ranked by mapped level bands. Group size, class mix, faction,
                    and current EQL difficulty can change the safest choice.
                  </p>
                </div>
              )}
              {levelInput &&
                advisorLevel === null &&
                (!Number.isInteger(Number(levelInput)) ||
                  Number(levelInput) < 1 ||
                  Number(levelInput) > 60) && (
                  <p className="levelerror" role="alert">
                    Enter a whole level from 1 to 60.
                  </p>
                )}
            </section>
          )}
          {tab === 'Quick' && (
            <section
              className={`realmstage ${realms[realm].tone}`}
              style={{
                backgroundImage: `linear-gradient(90deg,rgba(7,10,8,.88) 0%,rgba(7,10,8,.22) 57%,rgba(7,10,8,.08) 100%),url(${realms[realm].image})`,
              }}
            >
              <div className="realmcopy">
                <small>
                  PEOPLES & HOMELANDS · {String(realm + 1).padStart(2, '0')}
                </small>
                <h2>{realms[realm].name}</h2>
                <p>{realms[realm].subtitle}</p>
                <div className="racechips">
                  {realms[realm].races.map((r) => (
                    <button key={r} onClick={() => setQuery(r)}>
                      {r}
                    </button>
                  ))}
                </div>
                <span>{realms[realm].places}</span>
              </div>
              <div className="realmtabs" aria-label="Choose a realm">
                {realms.map((r, i) => (
                  <button
                    key={r.name}
                    className={realm === i ? 'active' : ''}
                    onClick={() => setRealm(i)}
                  >
                    <b>{r.name}</b>
                    <span>{r.races.join(' · ')}</span>
                  </button>
                ))}
              </div>
            </section>
          )}
          {edit && (
            <section className="profileedit">
              <div className="cardhead">
                <div>
                  <small>CHARACTER PROFILE</small>
                  <h2>{profile.name}</h2>
                </div>
                <button onClick={() => setEdit(false)}>Done</button>
              </div>
              <div className="formgrid">
                {(['level', 'build', 'location', 'goal'] as const).map((k) => (
                  <label key={k}>
                    {k}
                    <input
                      value={profile[k]}
                      onChange={(e) => updateProfile(k, e.target.value)}
                      placeholder={
                        k === 'build'
                          ? 'e.g. WAR / CLR'
                          : k === 'goal'
                            ? 'XP, gear, faction…'
                            : ''
                      }
                    />
                  </label>
                ))}
              </div>
            </section>
          )}
          {tab === 'Instances' && (
            <DungeonGuide initialDungeon={selectedInstance} />
          )}
          {tab === 'Logs' && <LogReader />}
          {tab === 'Loot' && (
            <section className="lootcoverage" aria-label="Loot search coverage">
              <div>
                <small>LIVE LOOT INDEX</small>
                <h2>
                  {lootIndexState === 'ready'
                    ? `${lootIndex.length.toLocaleString()} measured EQL drops ready`
                    : lootIndexState === 'loading'
                      ? 'Loading measured EQL drops…'
                      : 'Measured feed is temporarily unavailable'}
                </h2>
                <p>
                  The main search now matches item names, dropping mobs, and
                  observed zones. Every result below came from an EQL combat-log
                  sighting; counts are observations, never invented drop rates.
                </p>
              </div>
              <div className="lootsources">
                <a href={EQL_SOURCE_INDEX} target="_blank" rel="noreferrer">
                  <b>EQL Source</b>
                  <span>Measured drops · strongest public evidence</span>
                </a>
                <a href={EQLBASE_ITEMS} target="_blank" rel="noreferrer">
                  <b>EQLBase full catalog</b>
                  <span>9,360 items · EQL-observed + labeled baseline</span>
                </a>
              </div>
              <p className="coveragewarning">
                No public source currently proves every mob-loot item across all
                of EQL. EQLSaK shows everything in the measured feed and keeps the
                broader baseline separate so “possible” never masquerades as
                “verified.”
              </p>
            </section>
          )}
          {tab === 'Atlas' && (
            <>
              <section className="atlasnav">
                <div className="continenttabs">
                  {atlasMaps.map((m, i) => (
                    <button
                      key={m.name}
                      className={atlas === i ? 'active' : ''}
                      onClick={() => {
                        setAtlas(i);
                        setZoom(1);
                      }}
                    >
                      <span>0{i + 1}</span>
                      <b>{m.name}</b>
                      <small>{m.nodes.length} mapped places</small>
                    </button>
                  ))}
                </div>
                <div className="mapfilters">
                  <button
                    className={mapType === 'all' ? 'active' : ''}
                    onClick={() => setMapType('all')}
                  >
                    All
                  </button>
                  <button
                    className={mapType === 'city' ? 'active' : ''}
                    onClick={() => setMapType('city')}
                  >
                    Cities
                  </button>
                  <button
                    className={mapType === 'dungeon' ? 'active' : ''}
                    onClick={() => setMapType('dungeon')}
                  >
                    Dungeons
                  </button>
                  <button
                    className={mapType === 'wild' ? 'active' : ''}
                    onClick={() => setMapType('wild')}
                  >
                    Outdoors
                  </button>
                </div>
              </section>
              <section className="atlasframe">
                <div className="atlashead">
                  <div className="atlasidentity">
                    <small>CARTOGRAPHIC RECONSTRUCTION · EQL CONNECTIONS</small>
                    <h2>{atlasMaps[atlas].name}</h2>
                    <p>{atlasMaps[atlas].subtitle}</p>
                  </div>
                  <div className="zoomcontrols">
                    <button
                      onClick={() => setZoom((z) => Math.max(1, z - 0.2))}
                      aria-label="Zoom out"
                    >
                      <Minus />
                    </button>
                    <span>{Math.round(zoom * 100)}%</span>
                    <button
                      onClick={() => setZoom((z) => Math.min(1.8, z + 0.2))}
                      aria-label="Zoom in"
                    >
                      <Plus />
                    </button>
                  </div>
                </div>
                <div className="atlasviewport">
                  <div
                    className="atlaslayer"
                    style={{
                      backgroundImage: `url(${atlasMaps[atlas].image})`,
                      transform: `scale(${zoom})`,
                    }}
                  >
                    {atlasMaps[atlas].nodes.map(
                      ([name, x, y, level, type]) =>
                        (mapType === 'all' || mapType === type) && (
                          <button
                            key={name}
                            className={`mapnode ${type}${vendorCity === name ? ' vendorfocus' : ''}`}
                            style={{ left: `${x}%`, top: `${y}%` }}
                            onClick={() => {
                              if (type === 'city' && vendorRecords.some((vendor) => vendor.zone === name)) {
                                setVendorCity(name);
                                setSelected(null);
                                return;
                              }
                              const rendered = [
                                'Blackburrow',
                                'Castle Mistmoore',
                                'Najena',
                                'Lower Guk',
                                'Splitpaw Lair',
                                'Befallen',
                              ];
                              if (
                                type === 'dungeon' &&
                                rendered.includes(name)
                              ) {
                                setSelectedInstance(name);
                                setTab('Instances');
                                setQuery('');
                              } else {
                                setQuery(name);
                              }
                            }}
                            title={
                              type === 'dungeon'
                                ? 'Open this dungeon dossier'
                                : `Search field records for ${name}`
                            }
                          >
                            <i />
                            <span>
                              {name}
                              <small>{level}</small>
                            </span>
                          </button>
                        ),
                    )}
                  </div>
                  <div className="maplegend">
                    <span>
                      <i className="city" />
                      City
                    </span>
                    <span>
                      <i className="dungeon" />
                      Dungeon
                    </span>
                    <span>
                      <i className="wild" />
                      Outdoor
                    </span>
                    <span>
                      <Ship />
                      Travel
                    </span>
                  </div>
                  {vendorCity && vendorRecords.some((vendor) => vendor.zone === vendorCity) && (
                    <aside className="vendortray" aria-label={`${vendorCity} vendors`}>
                      <button className="vendorclose" onClick={() => setVendorCity(null)} aria-label="Close vendor list"><X /></button>
                      <small>CITY VENDOR DIRECTORY</small>
                      <h3>{vendorCity}</h3>
                      <p>Select a vendor for wares, location notes, and provenance.</p>
                      <div>
                        {vendorRecords.filter((vendor) => vendor.zone === vendorCity).map((vendor) => (
                          <button key={vendor.id} onClick={() => setSelected(vendor)}>
                            <b>{vendor.name}</b>
                            <span>{vendor.summary.replace(` · ${vendorCity}`, '')}</span>
                          </button>
                        ))}
                      </div>
                      <em className="badge legacy">Legacy EQ unverified</em>
                    </aside>
                  )}
                </div>
              </section>
              <section className="routebar">
                <div>
                  <label>
                    ROUTE FROM
                    <select
                      value={from}
                      onChange={(e) => setFrom(e.target.value)}
                    >
                      {routeStops.map((z) => (
                        <option key={z}>{z}</option>
                      ))}
                    </select>
                  </label>
                  <ChevronRight />
                  <label>
                    TO
                    <select value={to} onChange={(e) => setTo(e.target.value)}>
                      {routeStops.map((z) => (
                        <option key={z}>{z}</option>
                      ))}
                    </select>
                  </label>
                </div>
                {route.length ? (
                  <ol>
                    {route.map((z, i) => (
                      <li key={z}>
                        <b>{i + 1}</b>
                        {z}
                      </li>
                    ))}
                  </ol>
                ) : (
                  <p>No verified connection path is mapped yet.</p>
                )}
              </section>
            </>
          )}
          {tab !== 'Atlas' && tab !== 'Instances' && tab !== 'Logs' && (
            <div className="grid">
              <section className="mapcard">
                <div className="cardhead">
                  <div>
                    <small>
                      {tab === 'Manual' ? 'KNOWLEDGE INDEX' : 'CONNECTED WORLD'}
                    </small>
                    <h2>
                      {tab === 'Manual'
                        ? 'Browse by provenance'
                        : 'Zone routefinder'}
                    </h2>
                  </div>
                  <span>{records.length} records</span>
                </div>
                {tab !== 'Manual' ? (
                  <div className="mapcanvas">
                    <svg viewBox="0 0 100 100" aria-label="Connected EQL zones">
                      <path d="M22 52 L39 35 L55 48 L73 62 M61 81 L84 27" />
                      {zonePoints.map(([name, x, y]) => (
                        <g key={name} onClick={() => setQuery(name)}>
                          <circle cx={x} cy={y} r="2.2" />
                          <text x={x + 3} y={y - 2}>
                            {name}
                          </text>
                          <text className="range" x={x + 3} y={y + 2}>
                            {records.find((r) => r.zone === name)?.level ||
                              'mapped'}
                          </text>
                        </g>
                      ))}
                    </svg>
                  </div>
                ) : (
                  <div className="provenance">
                    <article>
                      <span className="badge verified">User-Verified EQL</span>
                      <p>
                        Direct observations, tests, screenshots, or measured
                        values from your play.
                      </p>
                    </article>
                    <article>
                      <span className="badge eql">EQL-specific source</span>
                      <p>
                        Current EQL documentation or community reports; useful,
                        but still open to field verification.
                      </p>
                    </article>
                    <article>
                      <span className="badge legacy">Legacy EQ unverified</span>
                      <p>
                        Classic EQ/P99 inheritance. Never allowed to overrule
                        EQL evidence.
                      </p>
                    </article>
                  </div>
                )}
              </section>
              <section className="intelcard">
                <div className="cardhead">
                  <div>
                    <small>{query ? 'SEARCH RESULTS' : 'FIELD INDEX'}</small>
                    <h2>
                      {visible.length +
                        (query
                          ? mappedSearchResults.length + lootSearchResults.length
                          : 0)}{' '}
                      {query ? 'matches' : 'entries'}
                    </h2>
                  </div>
                  <ShieldCheck />
                </div>
                <div className="recordlist">
                  {query
                    ? <>
                        {lootSearchResults.slice(0, 20).map((item) => {
                          const mobs = [...new Set(item.sightings.map((s) => s.mob))];
                          const zones = [
                            ...new Set(
                              item.sightings.flatMap((s) =>
                                s.sessions
                                  .map((session) => session.zone)
                                  .filter((zone): zone is string => Boolean(zone)),
                              ),
                            ),
                          ];
                          const observations = item.sightings.reduce(
                            (total, sighting) => total + sighting.seen,
                            0,
                          );
                          return (
                            <button
                              className="result lootresult"
                              key={`loot-${item.name}`}
                              onClick={() =>
                                setSelected({
                                  id: `measured-${item.name}`,
                                  type: 'Item',
                                  name: item.name,
                                  summary: `Measured dropping from ${mobs.slice(0, 4).join(', ')}${mobs.length > 4 ? ` and ${mobs.length - 4} more` : ''}.`,
                                  source: 'EQL-specific source',
                                  mob: mobs[0],
                                  zone: zones[0],
                                  details: [
                                    `${observations.toLocaleString()} total observed drop${observations === 1 ? '' : 's'} across ${item.sightings.length} mob record${item.sightings.length === 1 ? '' : 's'}. This is not a drop rate.`,
                                    `Dropping mobs: ${mobs.join(' · ')}`,
                                    zones.length
                                      ? `Observed zones: ${zones.join(' · ')}`
                                      : 'The source log did not identify a zone for this sighting.',
                                    'Live measured-drop data supplied by EQL Source.',
                                  ],
                                })
                              }
                            >
                              <span>
                                <i>
                                  ITEM · {observations.toLocaleString()} OBSERVED
                                </i>
                                {item.name}
                                <small>
                                  {mobs.slice(0, 3).join(' · ')}
                                  {zones.length ? ` · ${zones.slice(0, 2).join(' / ')}` : ''}
                                </small>
                                <em className="badge eql">Measured EQL drop</em>
                              </span>
                              <ChevronRight />
                            </button>
                          );
                        })}
                        {mappedSearchResults.slice(0, 20).map((place) => (
                          <button
                            className="result"
                            key={`map-${place.mapIndex}-${place.name}`}
                            onClick={() => openMappedLocation(place)}
                          >
                            <span>
                              <i>
                                MAP · {String(place.kind).toUpperCase()}
                                {place.level ? ` · ${place.level}` : ''}
                              </i>
                              {place.name}
                              <small>
                                Open in the {atlasMaps[place.mapIndex].name} atlas.
                              </small>
                              <em className="badge eql">EQL atlas</em>
                            </span>
                            <ChevronRight />
                          </button>
                        ))}
                        {visible.slice(0, Math.max(0, 20 - mappedSearchResults.length - lootSearchResults.length)).map((r) => (
                        <button
                          className="result"
                          key={r.id}
                          onClick={() => openRecord(r)}
                        >
                          <span>
                            <i>
                              {r.type}
                              {r.level ? ` · ${r.level}` : ''}
                            </i>
                            {r.name}
                            <small>{r.summary}</small>
                            <em
                              className={`badge ${provenanceClass(r.source)}`}
                            >
                              {r.source}
                            </em>
                          </span>
                          <ChevronRight />
                        </button>
                        ))}
                        {lootIndexState === 'ready' && lootSearchResults.length === 0 && (
                          <div className="externalresults">
                            <small>NO MEASURED DROP MATCH</small>
                            <p>
                              Try the full baseline catalog for unverified or
                              not-yet-observed items.
                            </p>
                            <a href={EQLBASE_ITEMS} target="_blank" rel="noreferrer">
                              Search all 9,360 EQLBase items <ChevronRight />
                            </a>
                          </div>
                        )}
                      </>
                    : groupedVisible.map((section) => (
                        <section className="recordgroup" key={section.name}>
                          <header>
                            <h3>{section.name}</h3>
                            <span>{section.items.length}</span>
                          </header>
                          {section.items.map((r) => (
                            <button
                              className="result"
                              key={r.id}
                              onClick={() => openRecord(r)}
                            >
                              <span>
                                <i>
                                  {r.type}
                                  {r.level ? ` · ${r.level}` : ''}
                                </i>
                                {r.name}
                                <small>{r.summary}</small>
                                <em
                                  className={`badge ${provenanceClass(r.source)}`}
                                >
                                  {r.source}
                                </em>
                              </span>
                              <ChevronRight />
                            </button>
                          ))}
                        </section>
                      ))}
                </div>
              </section>
            </div>
          )}
          <footer>
            <strong>EQLSaK knowledge policy</strong> User-verified EQL always
            outranks EQL sources; EQL sources always outrank legacy EverQuest
            assumptions. Last structured from the master chat: Aug 29, 2026.
            <details className="releasepolicy">
              <summary>Release, privacy, and accuracy safeguards</summary>
              <div>
                <p><b>Unofficial project.</b> EQLSaK is a fan-made community reference and is not affiliated with, endorsed by, or sponsored by Daybreak Game Company.</p>
                <p><b>Local privacy.</b> Character profiles stay in this browser. Imported log files are processed on the player’s device and are not uploaded by this version.</p>
                <p><b>Accuracy.</b> User-Verified EQL records take priority. Proxy coordinates, legacy records, and incomplete routes remain visibly labeled and must not be represented as exact.</p>
                <p><b>Open source.</b> EQLSaK application code is licensed under MIT so the player community may inspect, copy, improve, and redistribute it. <a href="/downloads/eqlsak-source-v52.zip" download>Download the source snapshot</a>. Artwork, game data, trademarks, and third-party material retain their separate rights and provenance.</p>
                <p><b>Public-release lock.</b> Public launch remains blocked until core journeys pass, external references respond, and every release-critical location is either verified or clearly excluded from exact guidance.</p>
              </div>
            </details>
          </footer>
        </div>
      </section>
      {selected && (
        <div
          className="overlay"
          role="button"
          tabIndex={0}
          onClick={(event) => {
            if (event.target === event.currentTarget) setSelected(null);
          }}
          onKeyDown={(event) => {
            if (event.key === 'Escape' || event.key === 'Enter') setSelected(null);
          }}
        >
          <dialog open className="detail">
            <button className="close" onClick={() => setSelected(null)}>
              <X />
            </button>
            <span className={`badge ${provenanceClass(selected.source)}`}>
              {selected.source}
            </span>
            <small>
              {selected.type}
              {selected.level ? ` · LEVEL ${selected.level}` : ''}
            </small>
            <h2>{selected.name}</h2>
            <p>{selected.summary}</p>
            {selected.details && (
              <ul>
                {selected.details.map((x) => (
                  <li key={x}>{x}</li>
                ))}
              </ul>
            )}
            {selected.mob && (
              <button
                className="linktrail"
                onClick={() => setQuery(selected.mob!)}
              >
                <Swords />
                Mob: {selected.mob}
              </button>
            )}
            {selected.zone && (
              <button
                className="linktrail"
                onClick={() => {
                  setQuery(selected.zone!);
                  setTab('Atlas');
                  setSelected(null);
                }}
              >
                <Map />
                Zone: {selected.zone}
              </button>
            )}
            <div className="trail">
              <CircleDot /> {selected.type} <ChevronRight />{' '}
              {selected.mob || 'field record'} <ChevronRight />{' '}
              {selected.zone || 'EQL-wide'}
            </div>
          </dialog>
        </div>
      )}
    </main>
  );
}
