import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import './search.css';
import './splash-theme.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  metadataBase: new URL(
    'https://numbuh-one-eql-companion.cipherlox.chatgpt.site',
  ),
  title: 'EQL Swiss Army Knife · EQLSaK',
  description:
    'A two-player EQL field manual, log reader, routefinder, loot atlas, and verified knowledge base.',
  openGraph: {
    title: 'EQL Swiss Army Knife · EQLSaK',
    description:
      'Maps, instances, logs, routes, loot, and verified EQL field knowledge in one companion.',
    images: ['/og.png'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'EQL Swiss Army Knife · EQLSaK',
    description:
      'Maps, instances, logs, routes, loot, and verified EQL field knowledge in one companion.',
    images: ['/og.png'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
