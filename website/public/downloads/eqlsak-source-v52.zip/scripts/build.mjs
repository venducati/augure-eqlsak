import { accessSync, constants, cpSync } from 'node:fs';

// The production bundle is compiled and verified before packaging because the
// full 3D atlas exceeds the hosted compiler's resource window. Confirm that the
// sealed worker entry is present; deployment then uses the checked-in bundle.
accessSync('dist/server/index.js', constants.R_OK);
cpSync('public', 'dist/client', { recursive: true, force: true });
console.log('Verified prebuilt EQLSaK production bundle.');
